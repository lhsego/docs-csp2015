################################################################################
# The goal of this demonstration is to illustrate a fairly simple use of
# Trelliscope to visualize power usage and outdoor air temperatures measured
# at four retail buildings in 2010.
################################################################################

# This dataset contains recordings of the energy consumption and outdoor air 
# temperature of four retail buildings at various locations in the U.S. at 15 
# min. intervals during 2010. The measurements have been anonymized by applying 
# a random linear transformation.
# 
# The variables in the data are described below:
#
# building - An integer identifying each of the four buildings
# dateTime - The date and time when the power and temperature were recorded
# year - Integer indicating the year of the measurement
# date - The date of the measurement
# quarter - The quarter of the year (Q1, Q2, Q3, Q4)
# month - The month, represented as an integer (1, 2, ..., 12)
# monthName - The name of the month ("January", "Februrary", ..., "December")
# week -  Integer indicating the week in 2010 (1, 2, 3, ..., 53)
# weekDay - The day of the week ("Monday", "Tuesday", ..., "Sunday")
# day - Integer indicating the Julian day in 2010 (number of days since Jan 1, 
#    2010)
# OAT.F - Outdoor Air Temperature measured in Farenheit
# Power.KW - Instantaneous power consumption by the building at the date time, 
#    measured in Kilowatts

################################################################################
# Let's set the working directory for this example. You may have to change the
# path in the command below to correctly point to the 'power_demo' directory
################################################################################
setwd("~/demos/power_demo")

# Remove any left-over objects in the Global environment
rm(list = ls())

################################################################################
# Let's look at a couple of Trelliscope displays of these data
################################################################################
library(trelliscope)

# Open the connection to the pre-existing trelliscope visualization data base we
# created with the code that follows
vdbConn("vdb_power")

# Launch the trelliscope viewer.  Use Ctrl-C or ESC to stop the reviewer and 
# return the R prompt
# myport <- 8100 # use this when running locally on your own computer
myport <- Sys.getenv("TR_PORT") # use this on demo cluster
view(port = myport)

################################################################################
# If you'd like to see how this visualization was created, see below:
################################################################################

# Load the trelliscope package if we haven't already
library(trelliscope)

# Let's clear the workspace of any residual objects
rm(list = ls())

# We'll begin by reading in the data
d <- read.csv("retailBuildings.csv")

# Here are the first 6 rows
head(d)

# Now let's look at the structure of the data.
# Notice how there are 139740 rows and 12 columns, and that
# dateTime and date are stored as factors
str(d)

# Let's convert the dateTime and date to a POSIXct format so R can compute with
# them as dates
d$dateTime <- as.POSIXct(d$dateTime)
d$date <- as.POSIXct(d$date)
str(d)

# The summary method applied to a data frame can be helpful to get
# a feel for the values in the data
summary(d)

# It would be nice to see a tabulation of the categorial variables.
# We can do that like this:
with(d, table(building))

# To make tables for all the categorical variables, let's create a
# vector with the names of these variables so we can easily select them:
sel <- c("building", "year", "quarter", "month", "monthName", "week", "weekday")

# Now we use that vector to select those columns of 'd', and we can apply
# the table() function to each column (column-wise summaries are indicated by
# MARGIN = 2)
apply(d[,sel], MARGIN = 2, table)

# We can also make cross tabulations to get a sense of the counts of
# two categorical variables.  For example, let's look at month by building:
with(d, table(month, building))

# Now it's time to subdivide the data into meaningful groups and make a plot
# of each group.  Suppose we would like to see a time series plot of the
# energy consumption of each building for each day. To accomplish this, let's
# divide the data by date to create a distributed data frame (ddf) object
# using the divide() function from the datadr package, and then sort each 
# resulting data frame by building and the dateTime using the arrange() 
# function from the plyr package
library(plyr)
byDate <- divide(d, by = "date", postTransFn = function(x) arrange(x, building, dateTime))

# Let's look at a single element of the ddf:
str(byDate[1])

# Now let's compute the range of the power so we can use the same axes for all 
# the plots
powerLims <- range(d$Power.KW)
tempLims <- range(d$OAT.F)

# Now we create a function to plot the power usage in all 5 buildings for a 
# single day
power.by.time <- function(x) {

  # Get the x and y axis limits
  # Global limits for y
  ylim <- powerLims
  # Local limits for x
  xlim <- range(x$dateTime)

  # Set plotting options
  par(las = 2, mar = c(4, 4, 0.5, 0.5))

  # Create a blank plot
  with(x, plot(dateTime, Power.KW, type = "n", xlim = xlim, ylim = ylim,
               xlab = "", ylab = "Power (KW)"))

  # Add in the data for each building, giving each building a different color
  for (i in as.character(2:5)) {
    with(x[x$building == i,], 
       lines(dateTime, Power.KW, col = as.numeric(i) - 1, lwd = 2))
  }

  # Add a legend to the plot
  legend(xlim[1] + 0.5 * diff(xlim), ylim[1],
         paste("Building", 2:5),
         lty = 1, col = c(2:5) - 1, lwd = 3, yjust = 0)

  # Returning NULL is required by trelliscope when the plotting function is 
  # base R code (as opposed to plots generated by lattice or ggplot)
  return(NULL)

} # power.by.time()

# Test the plot on a single subset
power.by.time(byDate[[8]][[2]])

# Next we create cognostics function that defines the cognostics (measures of 
# interest) that will be calculated (and visualizable) for each plot.  Keep in 
# mind that each cognostic should consist of a scalar value.  The input to the 
# cognostics function ('x') is a dataframe that contains one split, or one 
# subset, of the data.  In this case it is a dataframe that contains all the 
# data for a given date.
kwCog <- function(x) { list(

  # Compute the max and min for each day
  max = cog(max(x$Power.KW, na.rm = TRUE), desc = "Max Power (KW)"),
  min = cog(min(x$Power.KW, na.rm = TRUE), desc = "Min Power (KW)"),

  # Some common statistics are built into trelliscope with their own cognostics functions.
  # For example, cogMean() and cogRange().
  meanPower = cogMean(x$Power.KW, desc = "Mean Power (KW)"),
  rangePower = cogRange(x$Power.KW, desc = "Range of Power (Max - Min) (KW)"),

  # Note that we use 'unique()' below because, for each subset, the value of 
  # month, week, and day are all repeated for a single date. So we use unique() 
  # to get a scalar value of these date variables
  month = cog(unique(x$monthName), desc = "Month Name"),
  week = cog(unique(x$week), desc = "Week in 2010"),
  day = cog(unique(x$day), desc = "Julian Day in 2010")

)} # kwCog()

# Test the cognostics function for the 7th subset
kwCog(byDate[[73]][[2]])

# Open connection to the trelliscope visualization database (vdb)
vdbConn("vdb_power", autoYes = TRUE)

# Create first display using Trelliscope's makeDisplay() function.  This writes
# the various plots to the vdb that can then be viewed with trelliscope.
makeDisplay(byDate, name = "Power_by_Day",
            desc = "Power time series for 2010 buildings by day",
            panelFn = power.by.time, cogFn = kwCog)

# Let's also create a related display of power versus temperature by date
power.v.temp <- function(x) {

  # Get the limits
  xlim <- tempLims
  ylim <- powerLims

  # Set plotting parameters
  par(las = 1, mar = c(4, 4, 0.5, 0.5))

  # Create a blank plot for outdoor air temp vs. power
  with(x, plot(OAT.F, Power.KW, type = "n", xlim = xlim, ylim = ylim,
               xlab = "Outside Air Temp (F)", ylab = "Power (KW)"))

  # Add points for each building with a different color
  for (i in as.character(2:5)) {
    with(x[x$building == i,], points(OAT.F, Power.KW, col = as.numeric(i)-1))
  }

  # Add in the legend
  legend(xlim[1], ylim[2],
         paste("Building", 2:5),
         pch = 1,
         col = c(2:5) - 1)

  # Returning NULL is required by trelliscope when the plotting function is 
  # base R code (as opposed to plots generated by lattice or ggplot)
  return(NULL)

} # power.v.temp()

# Test the plot on a single subset
power.v.temp(byDate[[8]][[2]])

# Make the trelliscope display
makeDisplay(byDate, name = "Power_vs_Temp_by_Day",
            desc = "Power vs. Temperature for 2010 buildings by day",
            panelFn = power.v.temp, cogFn = kwCog)

# Launch the trelliscope viewer (must be in Firefox, Chrome, or Safari--not 
# Internet Explorer)
# myport <- 8100 # use this when running locally
myport <- Sys.getenv("TR_PORT") # use this on demo cluster
view(port = myport)
